package com.radovan.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MainController {

	@RequestMapping(value = "/welcome",method = RequestMethod.GET)
	public String welcomePage() {
		return "welcome";
	}
	
	@RequestMapping(value = "/hello",method = RequestMethod.GET)
	public String helloPage() {
		return "hello1";
	}
	
	@RequestMapping(value = "/",method = RequestMethod.GET)
	public String startPage() {
		return "start";
	}
}
